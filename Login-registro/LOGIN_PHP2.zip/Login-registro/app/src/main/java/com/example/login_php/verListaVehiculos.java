package com.example.login_php;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import com.example.login_php.objetos.Vehiculo;
import java.util.ArrayList;
import java.util.List;

public class verListaVehiculos extends AppCompatActivity {

    private List<Vehiculo> listaVehiculos;
    private ArrayAdapter<Vehiculo> adapter;
    private ListView listViewVehiculos;
    // Asegúrate de tener una instancia de tu base de datos
    private Database database;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ver_lista_vehiculos);

        listViewVehiculos = findViewById(R.id.listViewVehiculos);
        listaVehiculos = new ArrayList<>();
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, listaVehiculos);
        listViewVehiculos.setAdapter(adapter);

        // Inicializar la base de datos
        database = new Database(this);

        // Cargar los vehículos desde la base de datos
        cargarVehiculosDesdeBaseDeDatos();
    }

    private void cargarVehiculosDesdeBaseDeDatos() {
        // Obtener todos los vehículos de la base de datos
        List<Vehiculo> vehiculos = database.obtenerTodosLosVehiculos();

        // Limpiar la lista actual de vehículos y agregar los vehículos recuperados
        listaVehiculos.clear();
        listaVehiculos.addAll(vehiculos);

        // Notificar al adaptador que los datos han cambiado
        adapter.notifyDataSetChanged();
    }
}
