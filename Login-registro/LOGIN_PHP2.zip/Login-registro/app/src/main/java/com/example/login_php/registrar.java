package com.example.login_php;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class registrar extends AppCompatActivity {
    EditText txtName, txtEmail, pass;
    Button btn_insert;
    Database database;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registrar);

        txtName = findViewById(R.id.ednombre);
        txtEmail = findViewById(R.id.etemail);
        pass = findViewById(R.id.etcontraseña);
        btn_insert = findViewById(R.id.btn_register);

        database = new Database(this);

        btn_insert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                insertData();
            }
        });
    }

    private void insertData() {
        String nombre = txtName.getText().toString().trim();
        String email = txtEmail.getText().toString().trim();
        String password = pass.getText().toString().trim();

        if (nombre.isEmpty()) {
            txtName.setError("Complete los campos");
            return;
        } else if (email.isEmpty()) {
            txtEmail.setError("Complete los campos");
            return;
        } else if (password.isEmpty()) {
            pass.setError("Complete los campos");
            return;
        }

        database.insertUser(database.getWritableDatabase(), nombre, email, password, "usuario");

        Toast.makeText(this, "Usuario registrado exitosamente", Toast.LENGTH_SHORT).show();

        Intent intent = new Intent(registrar.this, login.class);
        startActivity(intent);
        finish();
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finish();
    }

    public void login(View v) {
        startActivity(new Intent(getApplicationContext(), login.class));
        finish();
    }
}
