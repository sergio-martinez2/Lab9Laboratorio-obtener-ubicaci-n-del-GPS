package com.example.login_php;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import com.example.login_php.objetos.Vehiculo;
import java.util.ArrayList;
import java.util.List;

public class Database extends SQLiteOpenHelper {

    private static final String DB_NAME = "appcarga"; // el nombre de nuestra base de datos
    private static final int DB_VERSION = 1; // la versión de la base de datos

    Database(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE USUARIOS (_id INTEGER PRIMARY KEY AUTOINCREMENT, "
                + "NOMBRE TEXT, "
                + "EMAIL TEXT, "
                + "PASSWORD TEXT, "
                + "TIPO_USUARIO TEXT);");

        db.execSQL("CREATE TABLE VEHICULOS (_id INTEGER PRIMARY KEY AUTOINCREMENT, "
                + "MARCA TEXT, "
                + "MODELO TEXT, "
                + "PLACA TEXT, "
                + "COLOR TEXT);");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Aquí puedes manejar la actualización de la versión de la base de datos si es necesario
    }

    public void insertUser(SQLiteDatabase db, String nombre, String email, String password, String tipoUsuario) {
        ContentValues values = new ContentValues();
        values.put("NOMBRE", nombre);
        values.put("EMAIL", email);
        values.put("PASSWORD", password);
        values.put("TIPO_USUARIO", tipoUsuario);
        db.insert("USUARIOS", null, values);
    }

    public boolean checkUser(String email, String password) {
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.query("USUARIOS", // Tabla
                new String[]{"_id", "NOMBRE", "EMAIL", "PASSWORD", "TIPO_USUARIO"}, // Columnas
                "EMAIL=? AND PASSWORD=?", // Clausula WHERE
                new String[]{email, password}, // Valores de la clausula WHERE
                null, null, null);

        boolean userExists = (cursor.getCount() > 0);
        cursor.close();
        db.close();

        return userExists;
    }

    public void insertVehiculo(String marca, String modelo, String placa, String color) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("MARCA", marca);
        values.put("MODELO", modelo);
        values.put("PLACA", placa);
        values.put("COLOR", color);
        db.insert("VEHICULOS", null, values);
        db.close();
    }

    public List<Vehiculo> obtenerTodosLosVehiculos() {
        List<Vehiculo> listaVehiculos = new ArrayList<>();

        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query("VEHICULOS", // Tabla de vehículos
                null, // Todas las columnas
                null, // Sin cláusula WHERE
                null, // Sin argumentos para la cláusula WHERE
                null, // Sin agrupamiento
                null, // Sin condición de agrupamiento
                null); // Sin orden

        // Iterar sobre el cursor para obtener los vehículos
        if (cursor.moveToFirst()) {
            do {
                // Obtener los datos de cada vehículo del cursor
                String marca = cursor.getString(cursor.getColumnIndex("MARCA"));
                String modelo = cursor.getString(cursor.getColumnIndex("MODELO"));
                String placa = cursor.getString(cursor.getColumnIndex("PLACA"));
                String color = cursor.getString(cursor.getColumnIndex("COLOR"));

                // Crear un nuevo objeto Vehiculo y agregarlo a la lista
                Vehiculo vehiculo = new Vehiculo(marca, modelo, placa, color);
                listaVehiculos.add(vehiculo);
            } while (cursor.moveToNext());
        }

        // Cerrar el cursor y la base de datos
        cursor.close();
        db.close();

        // Devolver la lista de vehículos
        return listaVehiculos;
    }
}
